function deleteEmoji(event) {
    event.preventDefault();
    console.log("delete");
    console.log(event.target.parentNode.firstChild.innerText);
    browser.storage.local.set({"sla":event.target.parentNode.firstChild.innerText});
    console.log(event.target);
    event.target.parentNode.parentNode.removeChild(event.target.parentNode)
}

function addEmoji(event) {
    event.preventDefault();
    text = document.getElementById('in-entry').value;
    if (text !== "" && text !== null && text !== undefined) {
        document.getElementById('emoji-list').innerHTML += `<div class="badge"><span>${text}</span><button onclick="deleteEmoji(event)"><i class="material-icons">delete</i></button>`;
    }
}

function init(){
    let controls = document.getElementsByClassName('control');
    console.log(controls);
    console.log(controls.item(0));
    for (let i = 0; i < controls.length; i++) {
        controls.item(i).addEventListener('click', deleteEmoji, false);
    }
    //TODO Adiocionar busca por id do botao
    // let submitButton  = document.getElementsByClassName('bt-submit');
    // console.log(submitButton);
    // submitButton.addEventListener('click',addEmoji, false);
}
init();
console.log("init");